﻿using System.ComponentModel.DataAnnotations;

using System.ComponentModel.DataAnnotations;

namespace Web_API_CE.Model
{
    public class Event
    {
        public int id { get; set; }
        public string Event_Name { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public int No_of_participants { get; set; }
        //[Required]
    }
    public enum Priority
    {
        low, high
    }
}
