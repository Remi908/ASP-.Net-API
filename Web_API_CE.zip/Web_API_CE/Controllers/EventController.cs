﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Web_API_CE.Data;
using Web_API_CE.Model;

namespace Web_API_CE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventController : ControllerBase
    {
        private readonly EventDBContext _context;
        public EventController(EventDBContext context)
        => _context = context;
        [HttpGet]
        public async Task<IEnumerable<Event>> Get()
            => await _context.Events.ToListAsync();
        [HttpGet("id")]
        [ProducesResponseType(typeof(Event), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> Getbyname(int id)
        {
            var Event = await _context.Events.FindAsync(id);
            return Event == null ? NotFound() : Ok(Event);

        }

    }
}